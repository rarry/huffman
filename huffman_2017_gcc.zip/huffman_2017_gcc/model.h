#include "huffman.h"

void calculateFreq(char *inputFile, int freq[]);
